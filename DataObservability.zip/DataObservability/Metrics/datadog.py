import requests
import json
from datetime import datetime

## Dynamic Points
# Post time-series data that can be graphed on Datadog’s dashboards.

# # Template variables
# export NOW="$(date +%s)"
# # Curl command
# curl -X POST "https://api.datadoghq.com/api/v2/series" \
# -H "Accept: application/json" \
# -H "Content-Type: application/json" \
# -H "DD-API-KEY: ${DD_API_KEY}" \
# -d @- << EOF
# {
#   "series": [
#     {
#       "metric": "system.load.1",
#       "type": 0,
#       "points": [
#         {
#           "timestamp": 1636629071,
#           "value": 0.7
#         }
#       ],
#       "resources": [
#         {
#           "name": "dummyhost",
#           "type": "host"
#         }
#       ]
#     }
#   ]
# }
# EOF


class DataDog:

    def __init__(self, job_name: str = "", tags: list = [], preffix: str = ""):
        API_KEY = "d618822854902d8c67fc42ae858f6543"
        APP_KEY = "7b859c75b0517e22d80181d24ba21d7f572ae82e"

        self.time_start = datetime.now()
        self.job_name = job_name
        self.tags = tags
        self.preffix = "glue.job." if preffix == "" else preffix
        self.resources = [{"name": self.job_name, "type": "glue_job"}]

        self.series_buffer : dict = {
            "series": []
        }

        self.datadog_api_url_base: str = "https://us5.datadoghq.com/api/v2"
        self.headers: list = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "DD-API-KEY": API_KEY,
            "DD-APPLICATION-KEY": APP_KEY,
        }

    def close(self):

        time_stop = datetime.now()
        time_delta = (time_stop - self.time_start).microseconds
        now_timestamp: int = int(datetime.timestamp(time_stop))

        metric_name = "execution.time.total"
        points = [{"timestamp": now_timestamp, "value": time_delta}]

        self.series(metric=metric_name, points=points, type=1, is_buffer=True)

        metric_name = "execution.count"
        points = [{"timestamp": now_timestamp, "value": 1}]
        
        self.series(metric=metric_name, points=points, type=1)

    def post_series(self, series_data: dict = {}):
        try:
            api_url: str = f"{self.datadog_api_url_base}/series"

            print(f"url: {api_url}")
            print(f"Headers: {self.headers}")
            print(f"Data: {series_data}")

            req = requests.post(
                url=api_url, headers=self.headers, data=json.dumps(series_data)
            )

            print(f"request: {req.status_code}")

            return req
        except Exception as error:
            raise error

    def series(
        self,
        metric: str = "",
        points: list = [],
        resources: list = [],
        tags: list = [],
        is_buffer: bool = False,
        type: int = 1,
    ):

        # Types: 0 (unspecified), 1 (count), 2 (rate), and 3 (gauge)
        tags.extend(self.tags)
        resources.extend(self.resources)

        series_data: list = [
            {
                "metric": self.preffix + metric,
                "type": type,
                "points": points,
                "resources": resources,
                "tags": tags,
            }
        ]

        if type == 1 or type == 2:
            series_data[0].update({"interval": 60})

        if is_buffer:
            self.series_buffer['series'].extend(series_data)

        if not is_buffer:
            self.series_buffer['series'].extend(series_data)
            self.post_series(self.series_buffer)
