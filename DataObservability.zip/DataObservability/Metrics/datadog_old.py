import requests

# # Path parameters
# export metric_name="dist.http.endpoint.request"
# # Curl command
# curl -X POST "https://api.datadoghq.com/api/v2/metrics/${metric_name}/tags" \
# -H "Accept: application/json" \
# -H "Content-Type: application/json" \
# -H "DD-API-KEY: ${DD_API_KEY}" \
# -H "DD-APPLICATION-KEY: ${DD_APP_KEY}" \
# -d @- << EOF
# {
#   "data": {
#     "type": "manage_tags",
#     "id": "ExampleMetric",
#     "attributes": {
#       "tags": [
#         "app",
#         "datacenter"
#       ],
#       "metric_type": "gauge"
#     }
#   }
# }
# EOF

class DataDog:


    def __init__(self):
        API_KEY = 'd618822854902d8c67fc42ae858f6543'
        APP_KEY = '7b859c75b0517e22d80181d24ba21d7f572ae82e'

        self.datadog_api_url_base: str = "https://api.datadoghq.com/api/v2/metrics"
        self.headers: list = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json', 
            'DD-API-KEY': API_KEY,
            'DD-APPLICATION-KEY': APP_KEY
            }

    def metrics(self, metric_data:dict = {}):
        try:
            api_url: str = f"{self.datadog_api_url_base}/{metric_data['data']['id']}/tags"

            print(f"url: {api_url}")
            print(f"Headers: {self.headers}")

            req = requests.post(url=api_url,headers=self.headers, data=metric_data)

            print(f"request: {req.text}")

            return req
        except Exception as error:
            raise error
        
    def gauge(self, id: str = "", ):

        gauge_data: dict = {
            "data": {
                "type": "manage_tags",
                "id": id,
                "attributes": {
                "tags": [
                    "app",
                    "datacenter"
                ],
                "metric_type": "gauge"
                }
            }
        }

        #try:
        self.metrics(metric_data=gauge_data)
        #except Exception as error:
        #    print("error: {error}")